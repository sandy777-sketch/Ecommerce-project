this porject is build by Sandesh with the reference of other developers project.

## Backend

The backend of the application is built with NodeJS and ExpressJS and uses a MongoDB database to store the product and user data.



